## Credits
The project is improved with security checks, following examples inside the [Programmez! - Hors-Série 8: 100 % SÉCURITÉ / HACKING / OWASP / DEVSECOPS](https://www.programmez.com/page-devcon/devcon-5-securite-et-hacking)

Logo: [Name](https://thenounproject.com/icon/name-2456689/) by [Adrien Coquet](https://thenounproject.com/coquet_adrien/) from [NounProject.com](https://thenounproject.com/)